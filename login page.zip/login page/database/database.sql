CREATE DATABASE event_db;

USE event_db;

CREATE TABLE registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  date DATE NOT NULL,
  message TEXT,
  event VARCHAR(100) NOT NULL,
  image_path VARCHAR(255)
);