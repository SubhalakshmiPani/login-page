const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const bodyParser = require('body-parser');
const path = require('path');

// Initialize the Express app
const app = express();
app.use(bodyParser.json());

// Set up Multer for file upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/event_db', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch(err => {
    console.error('Error connecting to MongoDB:', err);
  });

// Define the schema and model for registration data
const registrationSchema = new mongoose.Schema({
  name: String,
  email: String,
  date: Date,
  message: String,
  event: String,
  image_path: String
});
const Registration = mongoose.model('Registration', registrationSchema);

// Endpoint for registration form submission
app.post('/register', upload.single('image'), (req, res) => {
  const { name, email, date, message, event } = req.body;
  const imagePath = req.file ? req.file.path : null;

  const registration = new Registration({
    name,
    email,
    date,
    message,
    event,
    image_path: imagePath
  });

  registration.save()
    .then(() => res.send('Registration successful'))
    .catch(err => res.status(500).send('Error saving registration: ' + err));
});

// Start the server
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
